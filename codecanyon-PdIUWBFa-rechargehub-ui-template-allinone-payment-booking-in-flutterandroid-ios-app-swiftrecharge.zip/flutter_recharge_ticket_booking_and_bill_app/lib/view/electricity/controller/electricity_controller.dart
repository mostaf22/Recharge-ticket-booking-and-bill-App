import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ElectricityController extends GetxController{
  TextEditingController accountNameController = TextEditingController();
  TextEditingController nickNameController = TextEditingController();
}