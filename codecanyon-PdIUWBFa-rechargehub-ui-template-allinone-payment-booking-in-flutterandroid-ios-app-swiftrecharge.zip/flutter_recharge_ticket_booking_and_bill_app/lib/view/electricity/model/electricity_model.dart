class ElectricityModel {
  String? image;
  String? title;
  // String? routeKey;

  ElectricityModel({
    this.image,
    this.title,
    // this.routeKey,
  });
}
