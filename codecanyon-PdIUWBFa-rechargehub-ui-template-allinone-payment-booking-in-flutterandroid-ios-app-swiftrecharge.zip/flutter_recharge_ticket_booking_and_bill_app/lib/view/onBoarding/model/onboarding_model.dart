class OnBoardModel {
  String? image;
  String? onboardTag;

  OnBoardModel({
    this.image,
    this.onboardTag,
  });
}
