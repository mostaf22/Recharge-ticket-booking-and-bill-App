import 'dart:ui';

class RecentRechargeModel {
  String? name;
  String? title;
  Color? color;
  Color? textColor;

  RecentRechargeModel({
    this.name,
    this.title,
    this.color,
    this.textColor,
  });
}
