class PaymentModel {
  String? image;
  String? name;

  PaymentModel({
    this.image,
    this.name,
  });
}
