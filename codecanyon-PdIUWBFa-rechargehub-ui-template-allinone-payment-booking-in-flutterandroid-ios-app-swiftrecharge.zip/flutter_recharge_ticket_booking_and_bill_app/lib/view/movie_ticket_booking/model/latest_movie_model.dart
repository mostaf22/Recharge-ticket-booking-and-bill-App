class LatestMovieModel {
  String? image;
  String? title;
  String? rate;

  LatestMovieModel({
    this.image,
    this.title,
    this.rate,
  });
}
