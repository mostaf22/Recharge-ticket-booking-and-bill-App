class TrendingMovieModel {
  String? image;
  String? title;

  TrendingMovieModel({
    this.image,
    this.title,
  });
}
