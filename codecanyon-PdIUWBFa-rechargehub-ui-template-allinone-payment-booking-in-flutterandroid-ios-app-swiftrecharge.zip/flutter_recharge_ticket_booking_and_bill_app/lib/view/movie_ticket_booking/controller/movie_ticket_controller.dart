import 'package:get/get.dart';

class MovieTicketController extends GetxController{
  RxInt selected = 0.obs;
}