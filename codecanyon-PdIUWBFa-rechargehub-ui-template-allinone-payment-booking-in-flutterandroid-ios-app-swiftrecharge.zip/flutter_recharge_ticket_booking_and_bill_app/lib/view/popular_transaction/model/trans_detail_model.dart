class TransDetailModel {
  String? type;
  String? detail;

  TransDetailModel({
    this.type,
    this.detail,
  });
}
