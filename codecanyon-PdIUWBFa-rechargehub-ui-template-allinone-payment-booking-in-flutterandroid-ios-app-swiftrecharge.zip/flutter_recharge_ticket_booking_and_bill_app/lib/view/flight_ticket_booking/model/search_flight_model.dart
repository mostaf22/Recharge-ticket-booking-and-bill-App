import 'dart:ui';

class SearchFlightModel {
  String? image;
  String? status;
  Color? statusColor;

  SearchFlightModel({
    this.image,
    this.status,
    this.statusColor,
  });
}
