class FlightTicketModel {
  String? name;

  FlightTicketModel({
    this.name,
  });
}
