class HelpModel {
  String? que;

  HelpModel({
    this.que,
  });
}
