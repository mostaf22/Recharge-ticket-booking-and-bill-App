class CardModel {
  String? image;
  String? card;

  CardModel({
    this.image,
    this.card,
  });
}
