class PlanDetailsModel {
  String? price;
  String? validity;
  String? des;

  PlanDetailsModel({
    this.price,
    this.validity,
    this.des,
  });
}
