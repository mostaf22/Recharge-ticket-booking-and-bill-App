class PackageCategoryModel {
  String? text;

  PackageCategoryModel({
    this.text,
  });
}
