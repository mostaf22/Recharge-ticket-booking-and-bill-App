class NotificationModel {
  String? title;
  String? time;

  NotificationModel({
    this.title,
    this.time,
  });
}
