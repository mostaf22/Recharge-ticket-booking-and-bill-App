class OfferModel {
  String? image;
  String? title;

  OfferModel({
    this.image,
    this.title,
  });
}
