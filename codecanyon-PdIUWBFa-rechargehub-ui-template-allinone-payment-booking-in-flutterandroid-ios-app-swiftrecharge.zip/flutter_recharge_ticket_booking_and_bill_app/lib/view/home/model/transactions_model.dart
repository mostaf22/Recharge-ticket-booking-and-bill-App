import 'dart:ui';

class TransactionModel {
  String? image;
  String? title;
  String? price;
  String? des;
  Color? color;

  TransactionModel({
    this.image,
    this.title,
    this.price,
    this.color,
    this.des,
  });
}
