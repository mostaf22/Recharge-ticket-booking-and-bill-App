class PopularTransModel {
  String? image;
  String? title;
  String? status;
  String? price;

  PopularTransModel({
    this.image,
    this.title,
    this.status,
    this.price,
  });
}
