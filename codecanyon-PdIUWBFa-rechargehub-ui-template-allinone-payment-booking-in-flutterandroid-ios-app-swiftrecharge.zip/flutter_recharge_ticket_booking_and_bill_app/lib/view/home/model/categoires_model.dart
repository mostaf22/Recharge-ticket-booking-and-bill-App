class CategoriesModel {
  String? image;
  String? title;
  String? routeKey;

  CategoriesModel({
    this.image,
    this.title,
    this.routeKey,
  });
}
