package com.app.recharge_ticket_booking_and_bill_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
